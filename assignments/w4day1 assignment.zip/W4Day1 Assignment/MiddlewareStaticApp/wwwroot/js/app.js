document.getElementById('btn')?.addEventListener('click', () => {
  alert('JS served as static file');
});
