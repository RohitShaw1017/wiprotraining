# EduLearn Course Management SPA

A Single Page Application built with Angular for managing courses, demonstrating Angular's core building blocks including components, modules, and data binding.

## Installation and Setup

- Node.js (version 14 or higher)
- Angular CLI
