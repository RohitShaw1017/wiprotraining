# NgRx Task Manager (Starter)
Add these files into an Angular workspace and run:
```
npm install @ngrx/store @ngrx/effects @ngrx/store-devtools
npm start
```
