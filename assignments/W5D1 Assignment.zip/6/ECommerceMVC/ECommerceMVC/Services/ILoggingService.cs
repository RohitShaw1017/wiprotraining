﻿namespace ECommerceMVC.Services
{
    public interface ILoggingService
    {
        void Log(string message);
    }
}
