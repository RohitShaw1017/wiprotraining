User Management Angular App - Minimal solution (lazy-loaded users module, fetches users from jsonplaceholder)
