import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService } from '../cart.service';
import { CartItem } from '../model';
import { Observable } from 'rxjs';
import { inject } from '@angular/core';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cart.component.html'
})
export class CartComponent {
  private cs = inject(CartService);
  items$: Observable<CartItem[]> = this.cs.items$;
  saved$: Observable<CartItem[]> = this.cs.saved$;

  increase(it: CartItem) {
    try { this.cs.updateQuantity(it.product.id, it.quantity + 1); } catch(e:any){ alert(e.message||'Error'); }
  }
  decrease(it: CartItem) {
    try { this.cs.updateQuantity(it.product.id, it.quantity - 1); } catch(e:any){ alert(e.message||'Error'); }
  }
  remove(it: CartItem) { this.cs.remove(it.product.id); }
  saveForLater(it: CartItem) { this.cs.saveForLater(it.product.id); }
  moveToCart(it: CartItem) { try { this.cs.moveToCartFromSaved(it.product.id); } catch(e:any){ alert(e.message||'Error'); } }
  checkout() { this.cs.checkout().then(()=> alert('Checkout successful! Cart cleared.')); }

  totalItems(items: CartItem[]) { return items.reduce((s,i)=>s+i.quantity,0); }
  totalPrice(items: CartItem[]) { return items.reduce((s,i)=>s + i.quantity * i.product.price, 0); }
}
