import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './product-list.component/product-list.component';
import { CartComponent } from './cart.component/cart.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ProductListComponent, CartComponent],
  template: `
  <div class="header">
    <h1>Shopping Cart (Standalone)</h1>
    <div><strong>Demo</strong></div>
  </div>
  <div class="container">
    <div class="products">
      <app-product-list></app-product-list>
    </div>
    <div class="cart">
      <app-cart></app-cart>
    </div>
  </div>
  `,
})
export class AppComponent {}
