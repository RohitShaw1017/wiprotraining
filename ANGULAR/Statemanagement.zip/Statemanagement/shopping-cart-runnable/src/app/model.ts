export interface Product {
  id: number;      // unique identifier
  name: string;    // product name
  price: number;   // product price
  stock: number;   // how many items are available
}

export interface CartItem {
  product: Product; // reference to a product
  quantity: number; // how many of that product is in the cart
}
