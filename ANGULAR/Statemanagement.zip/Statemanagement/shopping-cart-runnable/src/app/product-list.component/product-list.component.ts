import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from '../product.service';
import { CartService } from '../cart.service';
import { Product } from '../model';
import { inject } from '@angular/core';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-list.component.html'
})
export class ProductListComponent implements OnInit {
  private ps = inject(ProductService);
  private cs = inject(CartService);

  products: Product[] = [];
  loading = false;
  error: string | null = null;

  ngOnInit() {
    this.loading = true;
    this.ps.fetchProducts().subscribe({
      next: (p: Product[]) => { this.products = p; this.loading = false; },
      error: (err: any) => { this.error = err.message || 'Failed to load'; this.loading = false; }
    });
  }

  add(p: Product) {
    try {
      this.cs.addToCart(p,1);
      alert('Added to cart');
    } catch (e:any) {
      alert(e.message || 'Error');
    }
  }
}
