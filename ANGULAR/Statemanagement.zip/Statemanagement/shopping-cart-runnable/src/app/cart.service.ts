import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CartItem, Product } from './model';

@Injectable({ providedIn: 'root' })
export class CartService {
  private itemsSub = new BehaviorSubject<CartItem[]>([]);
  items$ = this.itemsSub.asObservable();

  private savedSub = new BehaviorSubject<CartItem[]>([]);
  saved$ = this.savedSub.asObservable();

  get items(): CartItem[] { return this.itemsSub.getValue(); }
  private set items(val: CartItem[]) { this.itemsSub.next(val); }

  get saved(): CartItem[] { return this.savedSub.getValue(); }
  private set saved(val: CartItem[]) { this.savedSub.next(val); }

  addToCart(product: Product, qty = 1) {
    const existing = this.items.find(i => i.product.id === product.id);
    if (existing) {
      const newQty = existing.quantity + qty;
      if (newQty > product.stock) throw new Error('Cannot add more than stock');
      existing.quantity = newQty;
    } else {
      if (qty > product.stock) throw new Error('Cannot add more than stock');
      this.items = [...this.items, { product, quantity: qty }];
    }
    this.items = [...this.items];
  }

  updateQuantity(productId: number, quantity: number) {
    const item = this.items.find(i => i.product.id === productId);
    if (!item) return;
    if (quantity <= 0) {
      this.remove(productId);
      return;
    }
    if (quantity > item.product.stock) throw new Error('Quantity exceeds stock');
    item.quantity = quantity;
    this.items = [...this.items];
  }

  remove(productId: number) {
    this.items = this.items.filter(i => i.product.id !== productId);
  }

  saveForLater(productId: number) {
    const idx = this.items.findIndex(i => i.product.id === productId);
    if (idx === -1) return;
    const [it] = this.items.splice(idx,1);
    this.items = [...this.items];
    this.saved = [...this.saved, it];
  }

  moveToCartFromSaved(productId: number) {
    const idx = this.saved.findIndex(i => i.product.id === productId);
    if (idx === -1) return;
    const [it] = this.saved.splice(idx,1);
    const existing = this.items.find(i => i.product.id === it.product.id);
    if (existing) {
      const newQty = existing.quantity + it.quantity;
      if (newQty > it.product.stock) throw new Error('Cannot move - exceeds stock');
      existing.quantity = newQty;
    } else {
      this.items = [...this.items, it];
    }
    this.saved = [...this.saved];
    this.items = [...this.items];
  }

  checkout(): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(() => {
        this.items = [];
        resolve();
      }, 500);
    });
  }
}
