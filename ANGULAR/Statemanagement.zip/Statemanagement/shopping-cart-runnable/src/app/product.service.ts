import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Product } from './model';
import { catchError } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ProductService {
  constructor(private http: HttpClient) {}

  fetchProducts(): Observable<Product[]> {
    return this.http.get<Product[]>('/assets/products.json')
      .pipe(
        catchError(err => {
          console.error('Products fetch failed', err);
          return throwError(() => new Error('Failed to load products'));
        })
      );
  }
}
